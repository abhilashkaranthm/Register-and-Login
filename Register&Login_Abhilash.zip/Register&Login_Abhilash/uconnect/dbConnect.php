<?php

	define('HOST','mysql5025.site4now.net');
	define('USER','a6ec9c_abcd123');
	define('PASS','Abhi@13a');
	define('DB','db_a6ec9c_abcd123');
	
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
	?>