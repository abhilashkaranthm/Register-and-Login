# Android User Login and Registration with Retrofit, Php and MySql

### NOTE =>uconnect folder is contain all php file and Database file. 

**Log In**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468354-cfdab6ce-5f4a-11e8-823e-d404de7ae29d.png width="320" height="600"/></br></br>
**Register User**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468356-d0078fd2-5f4a-11e8-8f70-8d8c380adcdc.png width="320" height="600"/></br></br>
**All User List**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468348-ceeeed34-5f4a-11e8-9a99-13c5d7fe4432.png width="320" height="600"/></br></br>
**User Details**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468350-cf1d9daa-5f4a-11e8-965f-60d212e21683.png width="320" height="600"/></br></br>
**All Options**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468351-cf49c4d4-5f4a-11e8-913c-ee0ccad1e4f4.png width="320" height="600"/></br></br>
**Edit Profile**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468352-cf774814-5f4a-11e8-82c6-ff81214a53ab.png width="320" height="600"/></br></br>
**Change Password**</br>
<img src=https://user-images.githubusercontent.com/34679133/40468353-cfa92028-5f4a-11e8-8b05-9b9af838fc6d.png width="320" height="600"/></br></br>
